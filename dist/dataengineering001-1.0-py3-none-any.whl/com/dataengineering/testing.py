from com.constants import constants

class testingutils:
    print("hello")
    print(constants.Constants.CSV)
    
    
